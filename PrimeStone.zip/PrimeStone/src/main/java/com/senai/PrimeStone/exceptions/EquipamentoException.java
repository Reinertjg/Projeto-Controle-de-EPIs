package com.senai.PrimeStone.exceptions;

public class EquipamentoException {

    public static class EmailJaCadastradoException extends RuntimeException {
        public EmailJaCadastradoException(String mensagem) {
            super(mensagem);
        }
    }

    public static class EquipamentoInvalidaException extends RuntimeException {
        public EquipamentoInvalidaException(String mensagem) {
            super(mensagem);
        }
    }

}
