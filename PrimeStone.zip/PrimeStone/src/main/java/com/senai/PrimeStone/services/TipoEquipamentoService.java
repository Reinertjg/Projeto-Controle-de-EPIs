package com.senai.PrimeStone.services;

import com.senai.PrimeStone.dtos.CadastroTipoEquipamentoDto;
import com.senai.PrimeStone.dtos.TipoEquipamentoDto;
import com.senai.PrimeStone.exceptions.TipoEquipamentoException;
import com.senai.PrimeStone.models.TipoEquipamentoModel;
import com.senai.PrimeStone.repositories.TipoEquipamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TipoEquipamentoService {

    @Autowired
    TipoEquipamentoRepository tipoequipamentoRepository;

    public List<TipoEquipamentoDto> obterListaTipoEquipamentos() {

        List<TipoEquipamentoModel> listaTipoEquipamentoModel = tipoequipamentoRepository.findByStatus("ativo");

        List<TipoEquipamentoDto> listaTipoEquipamento = new ArrayList<>();

        for (TipoEquipamentoModel tipoequipamento : listaTipoEquipamentoModel) {

            TipoEquipamentoDto tipoEquipamentoDto = new TipoEquipamentoDto();
            tipoEquipamentoDto.setId(tipoequipamento.getId());
            tipoEquipamentoDto.setDescricao(tipoequipamento.getDescricao());


            listaTipoEquipamento.add(tipoEquipamentoDto);
        }

        return listaTipoEquipamento;
    }

    public void cadastrarEquipamento(CadastroTipoEquipamentoDto cadastroTipoEquipamento) {
        // Verificando se já existe um equipamento do tipo e status "ativo"
        Optional<TipoEquipamentoModel> optionalTipoEquipamento = tipoequipamentoRepository.findByDescricaoAndStatus(cadastroTipoEquipamento.getDescricao(), "ativo");

        // Caso já exista um tipo equipamento, lança exceção
        if (optionalTipoEquipamento.isPresent()) {
            // Checa a descrição apenas se o equipamento já existe com o tipo ativo
            if (optionalTipoEquipamento.get().getDescricao().equals(cadastroTipoEquipamento.getDescricao())) {
                throw new TipoEquipamentoException.TipoEquipamentoInvalidaException("Já existe um tipo de equipamento com essa descrição.");
            }
        }

        // Criação e persistência do novo equipamento
        TipoEquipamentoModel tipoequipamento = new TipoEquipamentoModel();
        tipoequipamento.setDescricao(cadastroTipoEquipamento.getDescricao());

        tipoequipamentoRepository.save(tipoequipamento);
    }

    public boolean excluirTipoEquipamento(Long id) {

        Optional<TipoEquipamentoModel> optionalTipoEquipamento = tipoequipamentoRepository.findById(id);

        if (!optionalTipoEquipamento.isPresent()) {
            return false; // Se não encontrou o equipamento, não excluir
        }

        TipoEquipamentoModel tipoEquipamento = optionalTipoEquipamento.get();
        tipoEquipamento.setStatus("inativo");
        tipoequipamentoRepository.save(tipoEquipamento);

        return true;
    }

    public TipoEquipamentoDto obterTipoEquipamento(Long id) {

        Optional<TipoEquipamentoModel> optionalTipoEquipamento = tipoequipamentoRepository.findById(id);

        TipoEquipamentoDto tipoEquipamentoDto = new TipoEquipamentoDto();

        if (!optionalTipoEquipamento.isPresent()) {
            tipoEquipamentoDto.setId(0L);
            return tipoEquipamentoDto;
        }

        tipoEquipamentoDto.setId(optionalTipoEquipamento.get().getId());
        tipoEquipamentoDto.setDescricao(optionalTipoEquipamento.get().getDescricao());

        return tipoEquipamentoDto;
    }

    public void atualizarTipoEquipamento(TipoEquipamentoDto tipoEquipamentoDto, Long id) {
        // Busca o equipamento a ser atualizado com o id e status ativo
        Optional<TipoEquipamentoModel> optionalTipoEquipamento = tipoequipamentoRepository.findByIdAndStatus(id, "ativo");

        if (!optionalTipoEquipamento.isPresent()) {
            throw new TipoEquipamentoException.TipoEquipamentoInvalidaException("Equipamento não encontrado ou não ativo.");
        }

        // Verifica se já existe um outro equipamento com o mesmo tipo e descrição ativa
        Optional<TipoEquipamentoModel> optionalTipoEquipamentoTipoDescricao = tipoequipamentoRepository.findByDescricaoAndStatus(
                tipoEquipamentoDto.getDescricao(),
                "ativo"
        );

        if (optionalTipoEquipamentoTipoDescricao.isPresent()) {
            // Caso exista, lança uma exceção para evitar a duplicação
            throw new TipoEquipamentoException.TipoEquipamentoInvalidaException("Já existe um equipamento ativo com o mesmo tipo e descrição.");
        }

        // Obtém o equipamento que será atualizado
        TipoEquipamentoModel Tipoequipamento = optionalTipoEquipamento.get();

        // Atualiza os campos do equipamento
        Tipoequipamento.setDescricao(tipoEquipamentoDto.getDescricao());

        // Salva o equipamento atualizado no banco de dados
        tipoequipamentoRepository.save(Tipoequipamento);
    }


    public TipoEquipamentoService(TipoEquipamentoRepository tipoEquipamentoRepository) {
        this.tipoequipamentoRepository = tipoequipamentoRepository;
    }

    public List<TipoEquipamentoModel> listarTodos() {
        return tipoequipamentoRepository.findByStatus("ativo");
    }
}


