document.addEventListener('DOMContentLoaded', function () {
    let colaboradorIdParaExcluir = null; // Variável para armazenar o ID do colaborador

    // Captura o ID do colaborador ao abrir o modal
    document.querySelectorAll('.excluir').forEach(function (button) {
        button.addEventListener('click', function () {
            colaboradorIdParaExcluir = this.dataset.colaboradorId; // Obtém o ID do colaborador
            console.log('ID capturado para exclusão:', colaboradorIdParaExcluir); // Log no console
            $('#modalExcluirColaborador').modal('show'); // Abre o modal
        });
    });

    // Confirma e realiza a exclusão
    document.getElementById('btnExcluirConfirmar').addEventListener('click', function () {
        if (!colaboradorIdParaExcluir) {
            console.error('Nenhum ID foi capturado para exclusão!');
            alert('Erro: Nenhum ID foi capturado para exclusão.');
            return;
        }

        // Realiza a requisição DELETE
        fetch(`/colaborador/${colaboradorIdParaExcluir}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
        })
            .then(response => {
                if (response.ok) {
                    console.log('Colaborador excluído com sucesso:', colaboradorIdParaExcluir);
                    const row = document.querySelector(`button[data-colaborador-id="${colaboradorIdParaExcluir}"]`).closest('tr');
                    row.remove(); // Remove a linha da tabela
                    colaboradorIdParaExcluir = null; // Reseta o ID
                    $('#modalExcluirColaborador').modal('hide'); // Fecha o modal

                    // Verifica se a tabela está vazia
                    if (document.querySelectorAll('tbody tr').length === 0) {
                        document.querySelector('tbody').innerHTML = `
                            <tr>
                                <td colspan="8" class="text-center alert rodape" role="alert">
                                    Não há colaboradores cadastrados.
                                </td>
                            </tr>`;
                    }
                } else {
                    console.error('Erro ao excluir colaborador no servidor.');
                    alert('Erro ao excluir colaborador no servidor.');
                }
            })
            .catch(error => {
                console.error('Erro de rede:', error);
                alert('Erro ao conectar ao servidor.');
            });
    });
});
