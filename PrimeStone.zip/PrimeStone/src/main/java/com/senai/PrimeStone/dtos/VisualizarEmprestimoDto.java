package com.senai.PrimeStone.dtos;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Data
public class VisualizarEmprestimoDto {
    private Long id;

    private String nome;  // Alterado de ColaboradorModel para String
    private String descricao;  // Alterado de EquipamentoModel para String

    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private LocalDate dataInicial;

    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private LocalDate dataFinal;
}
