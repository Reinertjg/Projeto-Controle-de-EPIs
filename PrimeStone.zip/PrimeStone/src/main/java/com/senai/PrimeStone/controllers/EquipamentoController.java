package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.dtos.AtualizarUsuarioDto;
import com.senai.PrimeStone.dtos.CadastroEquipamentoDto;
import com.senai.PrimeStone.dtos.ColaboradorDto;
import com.senai.PrimeStone.dtos.EquipamentoDto;
import com.senai.PrimeStone.exceptions.EquipamentoException;
import com.senai.PrimeStone.exceptions.UsuarioException;
import com.senai.PrimeStone.services.EquipamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


@Controller
@RequestMapping("/equipamento")
public class EquipamentoController {

    @Autowired
    EquipamentoService equipamentoService;

    @PostMapping()
    public String cadastrarEquipamento(@ModelAttribute("equipamento") CadastroEquipamentoDto cadastroEquipamento, RedirectAttributes redirectAttributes) {

        try {
            equipamentoService.cadastrarEquipamento(cadastroEquipamento);
            return "redirect:/listaequipamentos";
        } catch (EquipamentoException.EquipamentoInvalidaException ex) {
            // Passa a mensagem de erro para o HTML
            redirectAttributes.addFlashAttribute("erro", ex.getMessage());
            return "redirect:/cadastrarequipamento";
        }
    }

    @PostMapping("/{id}")
    public String atualizarEquipamento(@ModelAttribute("equipamento") @PathVariable Long id, EquipamentoDto equipamentoDto, RedirectAttributes redirectAttributes){

        try {
            equipamentoService.atualizarEquipamento(equipamentoDto, id);
            return "redirect:/listaequipamentos";
        } catch (EquipamentoException.EquipamentoInvalidaException ex) {
            // Passa a mensagem de erro para o HTML
            redirectAttributes.addFlashAttribute("erro", ex.getMessage());
            return "redirect:/atualizarequipamento/{id}";
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> excluirEquipamento(@PathVariable Long id) {

        boolean sucesso = equipamentoService.excluirEquipamento(id);

        if (sucesso) {
            return ResponseEntity.ok("Equipamento excluído com sucesso.");
        }

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro ao excluir equipamento.");

    }
}
