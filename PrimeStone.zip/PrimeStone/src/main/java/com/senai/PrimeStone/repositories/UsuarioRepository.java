package com.senai.PrimeStone.repositories;

import com.senai.PrimeStone.models.UsuarioModel;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioRepository extends JpaRepository<UsuarioModel,Long> {
    
    //- Método que realiza o select no banco de dados filtrando no where o email do usuário
    public Optional<UsuarioModel> findByEmailAndStatus(String email, String status);

    List<UsuarioModel> findByStatus(String status);

    Optional<UsuarioModel> findByIdAndStatus(Long id, String status);
}