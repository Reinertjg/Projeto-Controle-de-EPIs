document.addEventListener('DOMContentLoaded', function () {
    let usuarioIdParaExcluir = null; // Variável para armazenar o ID do usuário

    // Captura o ID do usuário ao abrir o modal
    document.querySelectorAll('.excluir').forEach(function (button) {
        button.addEventListener('click', function () {
            usuarioIdParaExcluir = this.dataset.usuarioId; // Obtém o ID do usuário
            console.log('ID capturado para exclusão:', usuarioIdParaExcluir); // Verifique no console
            $('#exampleModal').modal('show'); // Abre o modal
        });
    });

    // Confirma e realiza a exclusão
    document.getElementById('btnExcluirConfirmar').addEventListener('click', function () {
        if (!usuarioIdParaExcluir) {
            console.error('Nenhum ID foi capturado para exclusão!');
            alert('Erro: Nenhum ID foi capturado para exclusão.');
            return;
        }

        // Realiza a requisição DELETE
        fetch(`/usuario/${usuarioIdParaExcluir}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
        })
            .then(response => {
                if (response.ok) {
                    console.log('Usuário excluído com sucesso:', usuarioIdParaExcluir);
                    const row = document.querySelector(`button[data-usuario-id="${usuarioIdParaExcluir}"]`).closest('tr');
                    row.remove(); // Remove a linha da tabela
                    usuarioIdParaExcluir = null; // Reseta o ID
                    $('#exampleModal').modal('hide'); // Fecha o modal

                    // Verifica se a tabela está vazia
                    if (document.querySelectorAll('tbody tr').length === 0) {
                        document.querySelector('tbody').innerHTML = `
                            <tr>
                                <td colspan="6" class="text-center alert rodape" role="alert">
                                    Não há usuários cadastrados.
                                </td>
                            </tr>`;
                    }
                } else {
                    console.error('Erro ao excluir usuário no servidor.');
                    alert('Erro ao excluir usuário no servidor.');
                }
            })
            .catch(error => {
                console.error('Erro de rede:', error);
                alert('Erro ao conectar ao servidor.');
            });
    });
});