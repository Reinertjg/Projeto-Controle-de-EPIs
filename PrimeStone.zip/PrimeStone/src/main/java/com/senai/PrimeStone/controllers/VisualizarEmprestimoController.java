package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.dtos.EmprestimoDto;
import com.senai.PrimeStone.dtos.VisualizarEmprestimoDto;
import com.senai.PrimeStone.services.ColaboradorService;
import com.senai.PrimeStone.services.EmprestimoService;
import com.senai.PrimeStone.services.EquipamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/visualizaremprestimo")
public class VisualizarEmprestimoController {

    @Autowired
    EmprestimoService emprestimoService;

    @Autowired
    ColaboradorService colaboradorService;

    @Autowired
    EquipamentoService equipamentoService;

    public VisualizarEmprestimoController(EquipamentoService equipamentoService, ColaboradorService colaboradorService) {
        this.equipamentoService = equipamentoService;
        this.colaboradorService = colaboradorService;
    }

    @GetMapping("/{id}")
    public String exibirVisualizarEmprestimo(Model model, @PathVariable Long id) {

        VisualizarEmprestimoDto emprestimo = emprestimoService.obterEmprestimo(id);

        model.addAttribute("emprestimoDto", emprestimo);

        model.addAttribute("colaboradores", colaboradorService.listarTodos());

        model.addAttribute("equipamentos", equipamentoService.listarTodos());

        if (emprestimo.getId() > 0) {
            return "visualizaremprestimo";
        }

        return "redirect:/listaemprestimos";

    }

}

