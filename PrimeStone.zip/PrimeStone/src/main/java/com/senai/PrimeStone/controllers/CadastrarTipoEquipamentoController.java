package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.dtos.CadastroDto;
import com.senai.PrimeStone.dtos.CadastroTipoEquipamentoDto;
import com.senai.PrimeStone.dtos.TipoEquipamentoDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping()
public class CadastrarTipoEquipamentoController {
   
    
    @GetMapping("/cadastrartipoequipamento")
    public String exibirListaUsuarios(Model model){
        
        CadastroTipoEquipamentoDto tipoequipamentoDto = new CadastroTipoEquipamentoDto();
        
        model.addAttribute("tipoequipamentoDto", tipoequipamentoDto);
        
        return "cadastrartipoequipamento";
    }
    
    
}
