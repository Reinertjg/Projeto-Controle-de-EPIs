package com.senai.PrimeStone.services;

import com.senai.PrimeStone.dtos.CadastroEquipamentoDto;
import com.senai.PrimeStone.dtos.EquipamentoDto;
import com.senai.PrimeStone.dtos.VisualizarEmprestimoDto;
import com.senai.PrimeStone.dtos.VisualizarEquipamentoDto;
import com.senai.PrimeStone.exceptions.EquipamentoException;
import com.senai.PrimeStone.exceptions.UsuarioException;
import com.senai.PrimeStone.models.*;
import com.senai.PrimeStone.repositories.EquipamentoRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.senai.PrimeStone.repositories.TipoEquipamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EquipamentoService {

    @Autowired
    EquipamentoRepository equipamentoRepository;

    @Autowired
    TipoEquipamentoRepository tipoEquipamentoRepository;

    public List<TipoEquipamentoModel> obterTodosTipoEquipamentos() {
        return tipoEquipamentoRepository.findByStatus("ativo");
    }

    public List<VisualizarEquipamentoDto> obterListaEquipamentos() {
        List<EquipamentoModel> listaEquipamentoModel = equipamentoRepository.findByStatus("ativo");
        List<VisualizarEquipamentoDto> listaEquipamento = new ArrayList<>();

        for (EquipamentoModel equipamento : listaEquipamentoModel) {
            VisualizarEquipamentoDto equipamentoDto = new VisualizarEquipamentoDto();
            equipamentoDto.setId(equipamento.getId());
            equipamentoDto.setDescricao(equipamento.getDescricao());
            // Atribuindo o tipo completo, não apenas a descrição
            equipamentoDto.setTipoEquipamento(equipamento.getTipoEquipamento());
            listaEquipamento.add(equipamentoDto);
        }
        return listaEquipamento;
    }


    public void cadastrarEquipamento(CadastroEquipamentoDto cadastroEquipamento) {

        // Verificando se já existe um equipamento do tipo e status "ativo"
        if (cadastroEquipamento.getId() == null) {
            EquipamentoModel equipamento = new EquipamentoModel();

            // Verifica se já existe um equipamento com o mesmo tipo e status "ativo"
            List<EquipamentoModel> equipamentosAtivos = equipamentoRepository.findByTipoAndStatus(
                    cadastroEquipamento.getTipoEquipamento().getId()

            );

            if (!equipamentosAtivos.isEmpty()) {
                // Verifica se alguma descrição já corresponde à enviada
                boolean descricaoExistente = equipamentosAtivos.stream()
                        .anyMatch(e -> e.getDescricao().equals(cadastroEquipamento.getDescricao()));

                if (descricaoExistente) {
                    throw new EquipamentoException.EquipamentoInvalidaException(
                            "Equipamento já cadastrado para o tipo especificado."
                    );
                }
            }

        }

        // Verifica se o tipo do equipamento está vazio
        if (cadastroEquipamento.getTipoEquipamento() == null || cadastroEquipamento.getTipoEquipamento().getId() == null) {
            throw new EquipamentoException.EquipamentoInvalidaException("Escolha um tipo de equipamento!!");
        }

        // Criação e persistência do novo equipamento
        EquipamentoModel equipamento = new EquipamentoModel();
        equipamento.setDescricao(cadastroEquipamento.getDescricao());

        TipoEquipamentoModel tipoEquipamento = tipoEquipamentoRepository.findById(cadastroEquipamento.getTipoEquipamento().getId())
                .orElseThrow(() -> new IllegalArgumentException("Equipamento não encontrado"));
        equipamento.setTipoEquipamento(tipoEquipamento);

        equipamentoRepository.save(equipamento);
    }

    public boolean excluirEquipamento(Long id) {

        Optional<EquipamentoModel> optionalEquipamento = equipamentoRepository.findById(id);

        if (!optionalEquipamento.isPresent()) {
            return false; // Se não encontrou o equipamento, não excluir
        }

        EquipamentoModel equipamento = optionalEquipamento.get();
        equipamento.setStatus("inativo");
        equipamentoRepository.save(equipamento);

        return true;
    }

    public VisualizarEquipamentoDto obterEquipamento(Long id) {
        Optional<EquipamentoModel> optionalEquipamento = equipamentoRepository.findById(id);

        if (!optionalEquipamento.isPresent()) {
            VisualizarEquipamentoDto equipamentoDto = new VisualizarEquipamentoDto();
            equipamentoDto.setId(0L);
            return equipamentoDto;
        }

        EquipamentoModel equipamento = optionalEquipamento.get();
        // Preenche o DTO com o objeto completo do tipo de equipamento
        VisualizarEquipamentoDto equipamentoDto = new VisualizarEquipamentoDto();
        equipamentoDto.setId(equipamento.getId());
        equipamentoDto.setDescricao(equipamento.getDescricao());
        equipamentoDto.setTipoEquipamento(equipamento.getTipoEquipamento()); // Preenchendo com o objeto TipoEquipamentoModel

        return equipamentoDto;
    }


    public void atualizarEquipamento(EquipamentoDto equipamentoDto, Long id) {
        // Busca o equipamento a ser atualizado com o id e status ativo
        EquipamentoModel equipamento = equipamentoRepository.findByIdAndStatus(id, "ativo")
                .orElseThrow(() -> new EquipamentoException.EquipamentoInvalidaException("Equipamento não encontrado ou não ativo."));

        // Verifica se já existe um outro equipamento com o mesmo tipo e descrição ativa
        Optional<EquipamentoModel> optionalEquipamentoTipoDescricao = equipamentoRepository.findEquipamentoPorTipoDescricaoEStatus(
                equipamentoDto.getTipoEquipamento().getId(),
                equipamentoDto.getDescricao(),
                "ativo"
        );

        if (optionalEquipamentoTipoDescricao.isPresent()) {
            // Caso exista, lança uma exceção para evitar a duplicação
            throw new EquipamentoException.EquipamentoInvalidaException("Já existe um equipamento ativo com o mesmo tipo e descrição.");
        }

        // Atualiza os campos do equipamento
        equipamento.setDescricao(equipamentoDto.getDescricao());
        equipamento.setTipoEquipamento(equipamentoDto.getTipoEquipamento());

        // Salva o equipamento atualizado no banco de dados
        equipamentoRepository.save(equipamento);
    }



    public EquipamentoService(EquipamentoRepository equipamentoRepository) {
        this.equipamentoRepository = equipamentoRepository;
    }

    public List<EquipamentoModel> listarTodos() {
        return equipamentoRepository.findByStatus("ativo");
    }
}


