package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.dtos.AtualizarUsuarioDto;
import com.senai.PrimeStone.dtos.CadastroDto;
import com.senai.PrimeStone.dtos.CadastroTipoEquipamentoDto;
import com.senai.PrimeStone.dtos.TipoEquipamentoDto;
import com.senai.PrimeStone.exceptions.TipoEquipamentoException;
import com.senai.PrimeStone.exceptions.UsuarioException;
import com.senai.PrimeStone.services.TipoEquipamentoService;
import com.senai.PrimeStone.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/tipoequipamento")
public class TipoEquipamentoController {
    
    @Autowired
    TipoEquipamentoService tipoEquipamentoService;
    
    @PostMapping()
    public String cadastrarTipoEquipamento(@ModelAttribute("tipoequipamento") CadastroTipoEquipamentoDto cadastro, RedirectAttributes redirectAttributes) {
        try {
            tipoEquipamentoService.cadastrarEquipamento(cadastro);
            return "redirect:/listatipoequipamentos";
        } catch (TipoEquipamentoException.TipoEquipamentoInvalidaException ex) {
            // Passa a mensagem de erro para o HTML
            redirectAttributes.addFlashAttribute("erro", ex.getMessage());
            return "redirect:/cadastrartipoequipamento";
        }
    }


    @PostMapping("/{id}")
    public String atualizarTipoEquipamento(@ModelAttribute("tipoequipamento") @PathVariable Long id, TipoEquipamentoDto atualizar, RedirectAttributes redirectAttributes){

        try {
            tipoEquipamentoService.atualizarTipoEquipamento(atualizar, id);
            return "redirect:/listatipoequipamentos";
        } catch (TipoEquipamentoException.TipoEquipamentoInvalidaException ex) {
            // Passa a mensagem de erro para o HTML
            redirectAttributes.addFlashAttribute("erro", ex.getMessage());
            return "redirect:/atualizartipoequipamento/{id}";
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String>  excluirTipoEquipamento(@PathVariable Long id){

        boolean sucesso = tipoEquipamentoService.excluirTipoEquipamento(id);

        if (sucesso){
            return ResponseEntity.ok("Tipo equipamento excluído com sucesso.");
        }

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro ao excluir tipo equipamento.");

    }
}
