document.addEventListener('DOMContentLoaded', function () {
    let emprestimoIdParaExcluir = null; // Variável para armazenar o ID do empréstimo

    // Adiciona evento aos botões de exclusão
    document.querySelectorAll('.excluir').forEach(function (button) {
        button.addEventListener('click', function () {
            emprestimoIdParaExcluir = this.dataset.emprestimoId; // Obtém o ID do empréstimo
            console.log('ID capturado para exclusão:', emprestimoIdParaExcluir); // Log no console
            $('#modalExcluirEmprestimo').modal('show'); // Abre o modal
        });
    });

    // Confirma a exclusão ao clicar no botão "Excluir" do modal
    document.getElementById('btnExcluirEmprestimoConfirmar').addEventListener('click', function () {
        if (!emprestimoIdParaExcluir) {
            console.error('Nenhum ID foi capturado para exclusão!');
            alert('Erro: Nenhum ID foi capturado para exclusão.');
            return;
        }

        // Realiza a requisição DELETE
        fetch(`/emprestimo/${emprestimoIdParaExcluir}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
        })
            .then(response => {
                if (response.ok) {
                    console.log('Empréstimo excluído com sucesso:', emprestimoIdParaExcluir);
                    const row = document.querySelector(`button[data-emprestimo-id="${emprestimoIdParaExcluir}"]`).closest('tr');
                    row.remove(); // Remove a linha da tabela
                    emprestimoIdParaExcluir = null; // Reseta o ID
                    $('#modalExcluirEmprestimo').modal('hide'); // Fecha o modal

                    // Verifica se a tabela está vazia
                    if (document.querySelectorAll('tbody tr').length === 0) {
                        document.querySelector('tbody').innerHTML = `
                            <tr>
                                <td colspan="8" class="text-center alert rodape" role="alert">
                                    Não há empréstimos cadastrados.
                                </td>
                            </tr>`;
                    }
                } else {
                    console.error('Erro ao excluir empréstimo no servidor.');
                    alert('Erro ao excluir empréstimo no servidor.');
                }
            })
            .catch(error => {
                console.error('Erro de rede:', error);
                alert('Erro ao conectar ao servidor.');
            });
    });
});
