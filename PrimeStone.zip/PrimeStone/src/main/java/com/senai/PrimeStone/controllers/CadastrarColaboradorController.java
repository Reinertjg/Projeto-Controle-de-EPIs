package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.dtos.CadastroColadoradorDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping()
public class CadastrarColaboradorController {

    @GetMapping("/cadastrarcolaborador")
    public String exibirListaColaborador(Model model){

        CadastroColadoradorDto cadastroDto = new CadastroColadoradorDto();

        model.addAttribute("CadastroColadoradorDto", cadastroDto);

        return "cadastrarcolaborador";
    }
}
