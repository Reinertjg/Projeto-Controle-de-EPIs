
function verificarAutenticacaoEmPaginasProtegidas() {
    const caminhoAtual = window.location.pathname;

    const padroesProtegidos = [
        /^\/home$/,
        /^\/listausuarios$/,
        /^\/listacolaboradores$/,
        /^\/listaequipamentos$/,
        /^\/listatipoequipamentos$/,
        /^\/listaemprestimos$/,
        /^\/cadastrarusuario$/,
        /^\/cadastrarcolaborador$/,
        /^\/cadastrarequipamento$/,
        /^\/cadastrartipoequipamento$/,
        /^\/cadastraremprestimo$/,
        /^\/visualizarusuario\/\d+$/,
        /^\/atualizarusuario\/\d+$/,
        /^\/atualizarcolaborador\/\d+$/,
        /^\/atualizarequipamento\/\d+$/,
        /^\/atualizartipoequipamento\/\d+$/,
        /^\/devolveremprestimo\/\d+$/,
        /^\/visualizarcolaborador\/\d+$/,
        /^\/visualizarequipamento\/\d+$/,
        /^\/visualizartipoequipamento\/\d+$/,
        /^\/visualizaremprestimo\/\d+$/,
    ];

    const protegido = padroesProtegidos.some(padrao => padrao.test(caminhoAtual));

    if (protegido) {
        window.onload = verificarAutenticacao;
    }
}


// Função verifica se o usuário está autenticado
function verificarAutenticacao() {
    const cookies = document.cookie.split("; ");
    const autenticadoCookie = cookies.find(cookie => cookie.startsWith("autenticado="));

    if (!autenticadoCookie || autenticadoCookie.split("=")[1] !== "true") {
        window.location.href = "/login"; // Redireciona para login se não estiver autenticado
    } else {
        document.body.classList.remove("hidden"); // Exibe o conteúdo
    }
}


// Executa a verificação ao carregar a página
verificarAutenticacaoEmPaginasProtegidas();


// Associar a função de logout ao botão de logout
if (document.querySelector(".cabecalho__menu_sair button")) {
    const logoutButton = document.querySelector(".cabecalho__menu_sair button");
    logoutButton.onclick = function(event) {
        event.preventDefault(); // Impede a ação padrão de envio do formulário
        logout(); // Chama a função de logout
    };


// Função para fazer o logout
    function logout() {
        // Exclui o cookie de autenticação
        document.cookie = "autenticado=; path=/; max-age=0"; // Definindo um tempo de expiração para 0 para excluir o cookie
        // Redireciona para a página de login
        window.location.href = "/login";
    }
}
