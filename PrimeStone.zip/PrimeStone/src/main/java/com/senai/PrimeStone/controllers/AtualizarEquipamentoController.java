package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.dtos.EquipamentoDto;
import com.senai.PrimeStone.dtos.VisualizarEquipamentoDto;
import com.senai.PrimeStone.services.EquipamentoService;
import com.senai.PrimeStone.services.TipoEquipamentoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/atualizarequipamento")
public class AtualizarEquipamentoController {

    @Autowired
    EquipamentoService equipamentoService;

    TipoEquipamentoService tipoEquipamentoService;

    // Injeção de dependência via construtor (está correta e preferível)
    public AtualizarEquipamentoController(TipoEquipamentoService tipoEquipamentoService) {
        this.tipoEquipamentoService = tipoEquipamentoService;
    }

    @GetMapping("/{id}")
    public String atualizarEquipamento(@Valid Model model, @PathVariable Long id) {
        VisualizarEquipamentoDto equipamentoDto = equipamentoService.obterEquipamento(id);

        if (equipamentoDto == null) {
            return "redirect:/listaequipamentos";
        }
        model.addAttribute("tipoequipamentos", tipoEquipamentoService.listarTodos());
        model.addAttribute("equipamentoDto", equipamentoDto);
        return "atualizarequipamento";
    }

    @PostMapping("/{id}")
    public String atualizarEquipamento(@Valid EquipamentoDto equipamentoDto, @PathVariable Long id) {
        equipamentoService.atualizarEquipamento(equipamentoDto, id);
        return "redirect:/listaequipamentos";
    }
}

