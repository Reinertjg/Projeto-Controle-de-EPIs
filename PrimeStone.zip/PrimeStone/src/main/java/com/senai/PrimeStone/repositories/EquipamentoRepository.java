package com.senai.PrimeStone.repositories;

import com.senai.PrimeStone.models.EquipamentoModel;

import java.util.List;
import java.util.Optional;

import com.senai.PrimeStone.models.UsuarioModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface EquipamentoRepository extends JpaRepository<EquipamentoModel, Long> {

    // Busca equipamentos ativos pelo tipo de equipamento
    @Query("SELECT e FROM EquipamentoModel e WHERE e.tipoEquipamento.id = :tipoId AND e.status = 'ativo'")
    List<EquipamentoModel> findByTipoAndStatus(@Param("tipoId") Long tipoId);

    List<EquipamentoModel> findByStatus(String status);

    Optional<EquipamentoModel> findByIdAndStatus(Long id, String ativo);

    // Busca equipamento específico pelo tipo, descrição e status
    @Query("SELECT e FROM EquipamentoModel e WHERE e.tipoEquipamento.id = :tipoId AND e.descricao = :descricao AND e.status = :status")
    Optional<EquipamentoModel> findEquipamentoPorTipoDescricaoEStatus(
            @Param("tipoId") Long tipoId,
            @Param("descricao") String descricao,
            @Param("status") String status);

}
