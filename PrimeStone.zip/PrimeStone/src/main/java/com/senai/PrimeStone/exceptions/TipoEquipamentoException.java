package com.senai.PrimeStone.exceptions;

public class TipoEquipamentoException {

    public static class TipoEquipamentoInvalidaException extends RuntimeException {
        public TipoEquipamentoInvalidaException(String mensagem) {
            super(mensagem);
        }
    }

}
