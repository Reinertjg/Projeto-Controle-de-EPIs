package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.dtos.EquipamentoDto;
import com.senai.PrimeStone.dtos.TipoEquipamentoDto;
import com.senai.PrimeStone.services.EquipamentoService;
import com.senai.PrimeStone.services.TipoEquipamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/visualizartipoequipamento")
public class VisualizarTipoEquipamentoController {

    @Autowired
    TipoEquipamentoService tipoEquipamentoService;

    @GetMapping("/{id}")
    public String exibirVisualizarTipoEquipamento(Model model, @PathVariable Long id) {

        TipoEquipamentoDto tipoEquipamento = tipoEquipamentoService.obterTipoEquipamento(id);

        model.addAttribute("tipoequipamentoDto", tipoEquipamento);

        if (tipoEquipamento.getId() > 0) {
            return "visualizartipoequipamento";
        }

        return "redirect:/listatipoequipamentos";

    }

}