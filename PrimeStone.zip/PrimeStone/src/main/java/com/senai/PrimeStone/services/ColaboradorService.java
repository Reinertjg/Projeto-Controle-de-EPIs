package com.senai.PrimeStone.services;

import com.senai.PrimeStone.dtos.CadastroColadoradorDto;
import com.senai.PrimeStone.dtos.ColaboradorDto;
import com.senai.PrimeStone.exceptions.ColaboradorException;
import com.senai.PrimeStone.exceptions.UsuarioException;
import com.senai.PrimeStone.models.ColaboradorModel;
import com.senai.PrimeStone.models.EquipamentoModel;
import com.senai.PrimeStone.repositories.ColaboradorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ColaboradorService {

    @Autowired
    ColaboradorRepository colaboradorRepository;

    public List<ColaboradorDto> obterListaColaboradores(){

        List<ColaboradorModel> listaColaboradorModel = colaboradorRepository.findByStatus("ativo");

        List<ColaboradorDto> listaColaborador = new ArrayList();

        for (ColaboradorModel colaborador : listaColaboradorModel){

            ColaboradorDto colaboradorDto = new ColaboradorDto();
            colaboradorDto.setId(colaborador.getId());
            colaboradorDto.setNome(colaborador.getNome());
            colaboradorDto.setEmail(colaborador.getEmail());
            colaboradorDto.setFuncao(colaborador.getFuncao());
            colaboradorDto.setDataNascimento(colaborador.getDataNascimento());

            listaColaborador.add(colaboradorDto);
        }

        return listaColaborador;

    }

    public void cadastrarColadorador(CadastroColadoradorDto cadastro) {
        Optional<ColaboradorModel> optionalColaborador = colaboradorRepository.findByEmailAndStatus(cadastro.getEmail(), "ativo");

        if (optionalColaborador.isPresent()) {
            throw new  ColaboradorException.EmailJaCadastradoException("O email já está cadastrado.");
        }

        if (cadastro.getDataNascimento().isAfter(LocalDate.now())) {
            throw new ColaboradorException.DataInvalidaException("A data de nascimento não pode ser no futuro.");
        }

        if (cadastro.getDataNascimento().isAfter(LocalDate.now().minusYears(14))) {
            throw new ColaboradorException.DataInvalidaException("O colaborador deve ter pelo menos 14 anos.");
        }

        if (cadastro.getDataNascimento().isBefore(LocalDate.now().minusYears(100))) {
            throw new ColaboradorException.DataInvalidaException("O colaborador não pode ter mais que 100 anos.");
        }

        System.out.println(cadastro.getDataNascimento());

        ColaboradorModel colaborador = new ColaboradorModel();
        colaborador.setNome(cadastro.getNome());
        colaborador.setEmail(cadastro.getEmail());
        colaborador.setFuncao(cadastro.getFuncao());
        colaborador.setDataNascimento(cadastro.getDataNascimento());

        colaboradorRepository.save(colaborador);
    }

    public void atualizarColaborador(ColaboradorDto atualizar, Long id){

        Optional<ColaboradorModel> optionalColaboradorID = colaboradorRepository.findById(id);
        // Verifica se o usuário com o ID inserido ja existe
        if(!optionalColaboradorID.isPresent()){
            throw new ColaboradorException.EmailJaCadastradoException(("O ID já está cadastrado."));
        }

        // Verifica se o usuário com o email inserido ja existe
        Optional<ColaboradorModel> optionalColaboradorEmail = colaboradorRepository.findByEmailAndStatus(atualizar.getEmail(), "ativo");
        if (optionalColaboradorEmail.isPresent() ) {
            if (!optionalColaboradorEmail.get().getEmail().equals(optionalColaboradorID.get().getEmail())) {
                throw new  UsuarioException.EmailCadastradoException("O email já está cadastrado.");
            }
        }

        if (atualizar.getDataNascimento().isAfter(LocalDate.now())) {
            throw new ColaboradorException.DataInvalidaException("A data de nascimento não pode ser no futuro.");
        }

        if (atualizar.getDataNascimento().isAfter(LocalDate.now().minusYears(14))) {
            throw new ColaboradorException.DataInvalidaException("O colaborador deve ter pelo menos 14 anos.");
        }

        ColaboradorModel colaborador = optionalColaboradorID.get();
        colaborador.setId(atualizar.getId());
        colaborador.setNome(atualizar.getNome());
        colaborador.setEmail(atualizar.getEmail());
        colaborador.setFuncao(atualizar.getFuncao());
        colaborador.setDataNascimento(atualizar.getDataNascimento());

        colaboradorRepository.save(colaborador);

    }

    public ColaboradorDto obterColaborador(Long id){

        Optional<ColaboradorModel> optionalColaborador = colaboradorRepository.findById(id);

        ColaboradorDto colaboradorDto = new ColaboradorDto();

        if (!optionalColaborador.isPresent()){
            colaboradorDto.setId(0L);
            return colaboradorDto;
        }

        System.out.println(optionalColaborador.get().getDataNascimento());

        colaboradorDto.setId(optionalColaborador.get().getId());
        colaboradorDto.setNome(optionalColaborador.get().getNome());
        colaboradorDto.setEmail(optionalColaborador.get().getEmail());
        colaboradorDto.setFuncao(optionalColaborador.get().getFuncao());
        colaboradorDto.setDataNascimento(optionalColaborador.get().getDataNascimento());


        return colaboradorDto;
    }

    public boolean excluirColaborador(Long id) {

        Optional<ColaboradorModel> optionalColaborador = colaboradorRepository.findById(id);

        if (!optionalColaborador.isPresent()) {
            return false; // Se não encontrou o colaborador, não excluir
        }

        ColaboradorModel colaborador = optionalColaborador.get();
        colaborador.setStatus("inativo");
        colaboradorRepository.save(colaborador);

        return true;
    }

    public List<ColaboradorModel> listarTodos() {
        return colaboradorRepository.findByStatus("ativo");
    }
}
