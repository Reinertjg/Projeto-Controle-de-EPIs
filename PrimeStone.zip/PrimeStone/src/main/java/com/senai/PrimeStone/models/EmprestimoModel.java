package com.senai.PrimeStone.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.LocalDate;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;


@Data
@Entity
@Table(name = "EMPRESTIMO")
public class EmprestimoModel {

    @Id
    @Column(name = "id_emprestimo")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JoinColumn(name = "colaborador")
    @ManyToOne
    private ColaboradorModel nome;

    @JoinColumn(name = "equipamento")
    @ManyToOne
    private EquipamentoModel descricao;

    @DateTimeFormat(pattern = "dd/MM/yyyy")
    @Column(name = "dataInicial", nullable = false, length = 90)
    private LocalDate dataInicial;

    @DateTimeFormat(pattern = "dd/MM/yyyy")
    @Column(name = "dataFinal", length = 90)
    private LocalDate dataFinal;

    @Column(name = "status", nullable = false, length = 90)
    private String status = "ativo";

}

