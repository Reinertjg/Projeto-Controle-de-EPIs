package com.senai.PrimeStone.models;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "TIPO_EQUIPAMENTO")
public class TipoEquipamentoModel {

    @Id
    @Column(name = "id_tipo")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "descricao", nullable = false, length = 90)
    private String descricao;

    @Column(name = "status", nullable = false, length = 90)
    private String status = "ativo";
}
