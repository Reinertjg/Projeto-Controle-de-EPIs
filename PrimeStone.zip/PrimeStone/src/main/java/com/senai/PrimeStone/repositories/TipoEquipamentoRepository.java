package com.senai.PrimeStone.repositories;

import com.senai.PrimeStone.models.TipoEquipamentoModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TipoEquipamentoRepository extends JpaRepository<TipoEquipamentoModel, Long> {

    public Optional<TipoEquipamentoModel> findByDescricaoAndStatus(String descricao, String status);

    List<TipoEquipamentoModel> findByStatus(String status);

    Optional<TipoEquipamentoModel> findByIdAndStatus(Long id, String ativo);
}
