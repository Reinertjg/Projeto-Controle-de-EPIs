package com.senai.PrimeStone.services;

import com.senai.PrimeStone.dtos.CadastroEmprestimoDto;
import com.senai.PrimeStone.dtos.EmprestimoDto;
import com.senai.PrimeStone.dtos.EquipamentoDto;
import com.senai.PrimeStone.dtos.VisualizarEmprestimoDto;
import com.senai.PrimeStone.exceptions.EmprestimoException;
import com.senai.PrimeStone.exceptions.EquipamentoException;
import com.senai.PrimeStone.exceptions.UsuarioException;
import com.senai.PrimeStone.models.ColaboradorModel;
import com.senai.PrimeStone.models.EmprestimoModel;
import com.senai.PrimeStone.models.EquipamentoModel;
import com.senai.PrimeStone.repositories.ColaboradorRepository;
import com.senai.PrimeStone.repositories.EmprestimoRepository;
import com.senai.PrimeStone.repositories.EquipamentoRepository;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmprestimoService {

    @Autowired
    ColaboradorRepository colaboradorRepository;

    @Autowired
    EquipamentoRepository equipamentoRepository;

    @Autowired
    EmprestimoRepository emprestimoRepository;

    //OBTEM TODOS OS EMPRESTIMOS CADASTRADOS
    public List<EmprestimoModel> obterTodosEmprestimos() {
        return emprestimoRepository.findByStatus("ativo");
    }

    //OBTEM TODOS OS COLABORADORES CADASTRADOS
    public List<ColaboradorModel> obterTodosColaboradores() {
        return colaboradorRepository.findByStatus("ativo");
    }
    //OBTEM TODOS OS EQUIPAMENTOS CADASTRADOS

    public List<EquipamentoModel> obterTodosEquipamentos() {
        return equipamentoRepository.findByStatus("ativo");
    }

    public List<VisualizarEmprestimoDto> obterListaEmprestimos() {

        List<EmprestimoModel> listaEmprestimoModel = emprestimoRepository.findByStatus("ativo");

        List<VisualizarEmprestimoDto> listaEmprestimo = new ArrayList<>();

        for (EmprestimoModel emprestimo : listaEmprestimoModel) {

            VisualizarEmprestimoDto emprestimoDto = new VisualizarEmprestimoDto();
            emprestimoDto.setId(emprestimo.getId());

            // Pegando os dados relevantes para o DTO
            emprestimoDto.setNome(emprestimo.getNome().getNome()); // Supondo que o nome do colaborador seja um campo String
            emprestimoDto.setDescricao(emprestimo.getDescricao().getDescricao()); // Supondo que a descrição do equipamento seja um campo String

            emprestimoDto.setDataInicial(emprestimo.getDataInicial());
            emprestimoDto.setDataFinal(emprestimo.getDataFinal());

            listaEmprestimo.add(emprestimoDto);
        }

        return listaEmprestimo;
    }

    public void cadastrarEmprestimo(CadastroEmprestimoDto cadastroEmprestimo) {

        if (cadastroEmprestimo.getId() == null) {
            EmprestimoModel emprestimo = new EmprestimoModel();

            // Verifica se o equipamento já está em uso
            List<EmprestimoModel> emprestimosAtivos = emprestimoRepository.findEmprestimosAtivosPorEquipamento(cadastroEmprestimo.getDescricao().getId());

            if (!emprestimosAtivos.isEmpty()) {
                // Equipamento já está em uso
                throw new  EmprestimoException.EmprestimoInvalidoException("Equipamento já esta emprestado a outro usuário.");
            }

            // Busca o Colaborador pelo ID
            ColaboradorModel colaborador = colaboradorRepository.findById(cadastroEmprestimo.getNome().getId())
                    .orElseThrow(() -> new IllegalArgumentException("Colaborador não encontrado"));
            emprestimo.setNome(colaborador);

            // Busca o Equipamento pelo ID
            EquipamentoModel equipamento = equipamentoRepository.findById(cadastroEmprestimo.getDescricao().getId())
                    .orElseThrow(() -> new IllegalArgumentException("Equipamento não encontrado"));
            emprestimo.setDescricao(equipamento);



            emprestimo.setDataInicial(LocalDate.now());

            emprestimoRepository.save(emprestimo);
        } else {
            Optional<EmprestimoModel> optionalEmprestimo = emprestimoRepository.findById(cadastroEmprestimo.getId());
        }
    }


    public boolean excluirEmprestimo(Long id) {

        Optional<EmprestimoModel> optionalEmprestimo = emprestimoRepository.findById(id);

        if (!optionalEmprestimo.isPresent()) {
            return false; // Se não encontrou o emprestimo, não excluir
        }

        EmprestimoModel emprestimo = optionalEmprestimo.get();
        emprestimo.setStatus("inativo");
        emprestimoRepository.save(emprestimo);

        return true;
    }

    public VisualizarEmprestimoDto obterEmprestimo(Long id) {

        // Verifica se o empréstimo está presente
        Optional<EmprestimoModel> optionalEmprestimo = emprestimoRepository.findById(id);

        // Se o empréstimo não existir, retorna um DTO com id 0
        if (!optionalEmprestimo.isPresent()) {
            VisualizarEmprestimoDto emprestimoDto = new VisualizarEmprestimoDto();
            emprestimoDto.setId(0L);
            return emprestimoDto;
        }

        // Pega o empréstimo do Optional
        EmprestimoModel emprestimo = optionalEmprestimo.get();

        // Busca o colaborador e o equipamento
        Optional<ColaboradorModel> colaboradorModel = colaboradorRepository.findById(emprestimo.getNome().getId());
        Optional<EquipamentoModel> equipamentoModel = equipamentoRepository.findById(emprestimo.getDescricao().getId());

        // Criação do DTO
        VisualizarEmprestimoDto emprestimoDto = new VisualizarEmprestimoDto();

        // Verifica se o colaborador e o equipamento estão presentes
        if (colaboradorModel.isPresent() && equipamentoModel.isPresent()) {
            emprestimoDto.setId(emprestimo.getId());
            emprestimoDto.setNome(colaboradorModel.get().getNome()); // Nome do colaborador
            emprestimoDto.setDescricao(equipamentoModel.get().getDescricao()); // Descrição do equipamento
            emprestimoDto.setDataInicial(emprestimo.getDataInicial());
            emprestimoDto.setDataFinal(emprestimo.getDataFinal());
        } else {
            // Se o colaborador ou equipamento não forem encontrados, retorna o id 0
            emprestimoDto.setId(0L);
        }

        return emprestimoDto;
    }

    public void devolverEmprestimo(VisualizarEmprestimoDto emprestimoDto, Long id) {

        Optional<EmprestimoModel> emprestimoModel = emprestimoRepository.findByIdAndStatus(emprestimoDto.getId(), "ativo");

        EmprestimoModel emprestimo = emprestimoModel.get();

        emprestimo.setDataFinal(LocalDate.now());

        // Salva o equipamento atualizado no banco de dados
        emprestimoRepository.save(emprestimo);

    }
}
