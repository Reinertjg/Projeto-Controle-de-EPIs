package com.senai.PrimeStone.exceptions;

public class EmprestimoException {

    public static class EmprestimoInvalidoException extends RuntimeException {
        public EmprestimoInvalidoException(String mensagem) {
            super(mensagem);
        }
    }

}
