package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.dtos.CadastroColadoradorDto;
import com.senai.PrimeStone.dtos.ColaboradorDto;
import com.senai.PrimeStone.exceptions.ColaboradorException;
import com.senai.PrimeStone.services.ColaboradorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/colaborador")
public class ColaboradorController {

    @Autowired
    ColaboradorService colaboradorService;

    @PostMapping()
    public String cadastrarColaborador(@ModelAttribute("colaborador") CadastroColadoradorDto cadastro, RedirectAttributes redirectAttributes) {
        try {
            colaboradorService.cadastrarColadorador(cadastro);
            return "redirect:/listacolaboradores";
        } catch (ColaboradorException.EmailJaCadastradoException | ColaboradorException.DataInvalidaException ex) {
            // Passa a mensagem de erro para o HTML
            redirectAttributes.addFlashAttribute("erro", ex.getMessage());
            return "redirect:/cadastrarcolaborador";
        }
    }

    @PostMapping("/{id}")
    public String atualizarColaborador(@ModelAttribute("colaborador") @PathVariable Long id, ColaboradorDto atualizar, RedirectAttributes redirectAttributes){

        try {
            colaboradorService.atualizarColaborador(atualizar, id);
            return "redirect:/listacolaboradores";
        } catch (ColaboradorException.EmailJaCadastradoException | ColaboradorException.DataInvalidaException ex) {
            // Passa a mensagem de erro para o HTML
            redirectAttributes.addFlashAttribute("erro", ex.getMessage());
            return "redirect:/atualizarcolaborador/{id}";
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> excluirColaborador(@PathVariable Long id) {

        boolean sucesso = colaboradorService.excluirColaborador(id);

        if (sucesso) {
            return ResponseEntity.ok("Colaborador excluído com sucesso.");
        }

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro ao excluir colaborador.");

    }

}
