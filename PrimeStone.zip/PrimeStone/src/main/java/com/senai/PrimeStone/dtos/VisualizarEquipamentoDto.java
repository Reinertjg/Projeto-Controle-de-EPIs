package com.senai.PrimeStone.dtos;

import com.senai.PrimeStone.models.TipoEquipamentoModel;
import lombok.Data;

@Data
public class VisualizarEquipamentoDto {

    private Long id;

    private String descricao;

    private TipoEquipamentoModel tipoEquipamento;

}
