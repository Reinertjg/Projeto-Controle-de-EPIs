package com.senai.PrimeStone.repositories;

import com.senai.PrimeStone.models.EmprestimoModel;
import com.senai.PrimeStone.models.EquipamentoModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface EmprestimoRepository extends JpaRepository<EmprestimoModel, Long> {

    public Optional<EmprestimoModel> findByIdAndStatus(Long id, String status);

    @Query("SELECT e FROM EmprestimoModel e WHERE e.descricao.id = :equipamentoId AND e.dataFinal IS NULL AND e.status = 'ativo'")
    List<EmprestimoModel> findEmprestimosAtivosPorEquipamento(@Param("equipamentoId") Long equipamentoId);


    List<EmprestimoModel> findByStatus(String status);

}
