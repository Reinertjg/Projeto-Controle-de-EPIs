package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.dtos.EquipamentoDto;
import com.senai.PrimeStone.services.ColaboradorService;
import com.senai.PrimeStone.services.EquipamentoService;
import com.senai.PrimeStone.services.TipoEquipamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping()
public class CadastrarEquipamentoController {

    private final TipoEquipamentoService tipoEquipamentoService;

    // Injeção de dependência via construtor (está correta e preferível)
    public CadastrarEquipamentoController(TipoEquipamentoService tipoEquipamentoService) {
        this.tipoEquipamentoService = tipoEquipamentoService;
    }

    @GetMapping("/cadastrarequipamento")
    public String exibirListaEquipamentos(Model model) {
        EquipamentoDto equipamentoDto = new EquipamentoDto();

        model.addAttribute("equipamentoDto", equipamentoDto);
        model.addAttribute("tipoequipamentos", tipoEquipamentoService.listarTodos());

        return "cadastrarequipamento";
    }
}

