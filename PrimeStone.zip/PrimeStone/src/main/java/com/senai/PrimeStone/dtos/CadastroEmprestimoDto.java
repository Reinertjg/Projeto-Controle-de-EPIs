package com.senai.PrimeStone.dtos;

import com.senai.PrimeStone.models.ColaboradorModel;
import com.senai.PrimeStone.models.EquipamentoModel;
import java.time.LocalDate;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

@Data
public class CadastroEmprestimoDto {
    private Long id;

    private ColaboradorModel nome;

    private EquipamentoModel descricao;

    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private LocalDate dataInicial;

    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private LocalDate dataFinal;
}

