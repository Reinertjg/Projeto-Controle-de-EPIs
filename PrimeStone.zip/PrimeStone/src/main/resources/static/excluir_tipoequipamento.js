document.addEventListener('DOMContentLoaded', function () {
    let tipoEquipamentoIdParaExcluir = null; // Variável para armazenar o ID do tipo de equipamento

    // Adiciona evento aos botões de exclusão
    document.querySelectorAll('.excluir').forEach(function (button) {
        button.addEventListener('click', function () {
            tipoEquipamentoIdParaExcluir = this.dataset.tipoequipamentoId; // Obtém o ID do tipo de equipamento
            console.log('ID capturado para exclusão:', tipoEquipamentoIdParaExcluir); // Log no console
            $('#modalExcluirTipoEquipamento').modal('show'); // Abre o modal
        });
    });

    // Confirma a exclusão ao clicar no botão "Excluir" do modal
    document.getElementById('btnExcluirTipoEquipamentoConfirmar').addEventListener('click', function () {
        if (!tipoEquipamentoIdParaExcluir) {
            console.error('Nenhum ID foi capturado para exclusão!');
            alert('Erro: Nenhum ID foi capturado para exclusão.');
            return;
        }

        // Realiza a requisição DELETE
        fetch(`/tipoequipamento/${tipoEquipamentoIdParaExcluir}`, {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
        })
            .then(response => {
                if (response.ok) {
                    console.log('Tipo de equipamento excluído com sucesso:', tipoEquipamentoIdParaExcluir);
                    const row = document.querySelector(`button[data-tipoequipamento-id="${tipoEquipamentoIdParaExcluir}"]`).closest('tr');
                    row.remove(); // Remove a linha da tabela
                    tipoEquipamentoIdParaExcluir = null; // Reseta o ID
                    $('#modalExcluirTipoEquipamento').modal('hide'); // Fecha o modal

                    // Verifica se a tabela está vazia
                    if (document.querySelectorAll('tbody tr').length === 0) {
                        document.querySelector('tbody').innerHTML = `
                            <tr>
                                <td colspan="6" class="text-center alert rodape" role="alert">
                                    Não há tipos de equipamentos cadastrados.
                                </td>
                            </tr>`;
                    }
                } else {
                    console.error('Erro ao excluir tipo de equipamento no servidor.');
                    alert('Erro ao excluir tipo de equipamento no servidor.');
                }
            })
            .catch(error => {
                console.error('Erro de rede:', error);
                alert('Erro ao conectar ao servidor.');
            });
    });
});
