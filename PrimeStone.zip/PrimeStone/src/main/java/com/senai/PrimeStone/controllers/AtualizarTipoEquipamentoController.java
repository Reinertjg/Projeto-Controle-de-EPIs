package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.dtos.EquipamentoDto;
import com.senai.PrimeStone.dtos.TipoEquipamentoDto;
import com.senai.PrimeStone.services.EquipamentoService;
import com.senai.PrimeStone.services.TipoEquipamentoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/atualizartipoequipamento")
public class AtualizarTipoEquipamentoController {

    @Autowired
    TipoEquipamentoService tipoEquipamentoService;

    @GetMapping("/{id}")
    public String atualizarTipoEquipamento(@Valid Model model, @PathVariable Long id) {
        TipoEquipamentoDto TipoEquipamento = tipoEquipamentoService.obterTipoEquipamento(id);

        if (TipoEquipamento == null) {
            return "redirect:/listatipoequipamentos";
        }

        model.addAttribute("tipoequipamentoDto", TipoEquipamento);
        return "atualizartipoequipamento";
    }

    @PostMapping
    public String atualizarEquipamento(@Valid TipoEquipamentoDto tipoEquipamentoDto, Long id) {
        tipoEquipamentoService.atualizarTipoEquipamento(tipoEquipamentoDto, id);
        return "redirect:/listatipoequipamentos";
    }
}

