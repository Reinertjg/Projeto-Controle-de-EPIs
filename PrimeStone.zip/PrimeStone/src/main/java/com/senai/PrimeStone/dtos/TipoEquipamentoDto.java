package com.senai.PrimeStone.dtos;

import lombok.Data;

@Data
public class TipoEquipamentoDto {

    private Long id;

    private String descricao;

}
