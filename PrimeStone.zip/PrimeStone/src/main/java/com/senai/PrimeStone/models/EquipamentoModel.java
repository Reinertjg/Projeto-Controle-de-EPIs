package com.senai.PrimeStone.models;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "EQUIPAMENTO")
public class EquipamentoModel {

    @Id
    @Column(name = "id_equipamento")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "descricao", nullable = false, length = 90)
    private String descricao;

    @JoinColumn(name = "tipo_equipamento")
    @ManyToOne
    private TipoEquipamentoModel tipoEquipamento;

    @Column(name = "status", nullable = false, length = 90)
    private String status = "ativo";

}
