package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.services.EmprestimoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping()
public class ListaEmprestimosController {

    @Autowired
    EmprestimoService emprestimoService;

    @GetMapping("/listaemprestimos")
    public String exibirListaColaboradores(@Valid Model model) {

        model.addAttribute("emprestimos", emprestimoService.obterListaEmprestimos());

        //--template : retorna o nome do arquivo html localizado lá na pasta templates.
        return "listaemprestimos";
    }

}

