package com.senai.PrimeStone.exceptions;

public class UsuarioException {

    public static class EmailCadastradoException extends RuntimeException {
        public EmailCadastradoException(String mensagem) {
            super(mensagem);
        }
    }

    public static class SenhaInvalidaException extends RuntimeException {
        public SenhaInvalidaException(String mensagem) {
            super(mensagem);
        }
    }

}
