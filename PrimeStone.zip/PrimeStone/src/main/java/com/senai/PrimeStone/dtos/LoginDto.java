package com.senai.PrimeStone.dtos;

import lombok.Data;

@Data
public class LoginDto {
    
    private Long id;
    
    private String email;
    
    private String senha;
}
