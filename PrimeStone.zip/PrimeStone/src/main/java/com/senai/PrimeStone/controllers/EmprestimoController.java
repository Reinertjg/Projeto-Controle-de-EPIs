package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.dtos.CadastroEmprestimoDto;
import com.senai.PrimeStone.dtos.EmprestimoDto;
import com.senai.PrimeStone.dtos.EquipamentoDto;
import com.senai.PrimeStone.dtos.VisualizarEmprestimoDto;
import com.senai.PrimeStone.exceptions.ColaboradorException;
import com.senai.PrimeStone.exceptions.EmprestimoException;
import com.senai.PrimeStone.exceptions.EquipamentoException;
import com.senai.PrimeStone.services.EmprestimoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/emprestimo")
public class EmprestimoController {

    @Autowired
    EmprestimoService emprestimoService;

    @PostMapping()
    public String cadastrarEmprestimo(@ModelAttribute("emprestimo") CadastroEmprestimoDto cadastroEmprestimo, RedirectAttributes redirectAttributes) {
        try {
            emprestimoService.cadastrarEmprestimo(cadastroEmprestimo);
            return "redirect:/listaemprestimos";
        } catch (EmprestimoException.EmprestimoInvalidoException ex) {
            // Passa a mensagem de erro para o HTML
            redirectAttributes.addFlashAttribute("erro", ex.getMessage());
            return "redirect:/cadastraremprestimo";
        }
    }

    @PostMapping("/{id}")
    public String devolverEmprestimo(@ModelAttribute("emprestimo") @PathVariable Long id, VisualizarEmprestimoDto emprestimoDto, RedirectAttributes redirectAttributes){

        try {
            emprestimoService.devolverEmprestimo(emprestimoDto, id);
            return "redirect:/listaemprestimos";
        } catch (EquipamentoException.EquipamentoInvalidaException ex) {
            // Passa a mensagem de erro para o HTML
            redirectAttributes.addFlashAttribute("erro", ex.getMessage());
            return "redirect:/devolveremprestimo/{id}";
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> excluirEmprestimo(@PathVariable Long id) {

        boolean sucesso = emprestimoService.excluirEmprestimo(id);

        if (sucesso) {
            return ResponseEntity.ok("Emprestimo excluído com sucesso.");
        }

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Erro ao excluir Emprestimo.");

    }
}
