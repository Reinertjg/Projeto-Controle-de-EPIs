package com.senai.PrimeStone.controllers;

import com.senai.PrimeStone.dtos.UsuarioDto;
import com.senai.PrimeStone.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/visualizarusuario")
public class VisualizarUsuarioController {
    
    @Autowired
    UsuarioService usuarioService;

    @GetMapping("/{id}")
    public String exibirVisualizarUsuario(Model model, @PathVariable Long id){
        try {
            UsuarioDto usuario = usuarioService.obterUsuario(id);
            model.addAttribute("usuarioDto", usuario);

            if (usuario.getId() > 0){
                return "visualizarusuario";
            }
        } catch (Exception e) {
            return "redirect:/listausuarios";
        }
        return "redirect:/listausuarios";
    }


}
