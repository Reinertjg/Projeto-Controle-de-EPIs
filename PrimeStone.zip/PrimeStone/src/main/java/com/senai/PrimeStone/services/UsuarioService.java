/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.senai.PrimeStone.services;

import com.senai.PrimeStone.dtos.*;
import com.senai.PrimeStone.exceptions.UsuarioException;
import com.senai.PrimeStone.models.ColaboradorModel;
import com.senai.PrimeStone.models.UsuarioModel;
import com.senai.PrimeStone.repositories.UsuarioRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.senai.PrimeStone.dtos.LoginSaveDto.getEmail;

@Service
public class UsuarioService {
    
    @Autowired
    UsuarioRepository usuarioRepository;
        
    public boolean validarLogin(LoginDto loginDto){
              
        Optional<UsuarioModel> optionalUsuario = usuarioRepository.findByEmailAndStatus(loginDto.getEmail(), "ativo");
        
        //--Verifica se achou o usuário no banco de dados pelo Email
        if (!optionalUsuario.isPresent()){
            //--Se não achou retorna erro
            return false;
        }
        
        //--Se achou o usuário pelo e-mail verifica se a senha esta correta!
        if (!optionalUsuario.get().getSenha().equals(loginDto.getSenha())){
            //--Se não esta correta retorna erro
            return false;
        }

        LoginSaveDto.setEmail(optionalUsuario.get().getEmail());

        return true;
    }
    
    public List<UsuarioDto> obterListaUsuarios(){
        
        List<UsuarioModel> listaUsuarioModel = usuarioRepository.findByStatus("ativo");
        
        List<UsuarioDto> listaUsuario = new ArrayList();
        
        for (UsuarioModel usuario : listaUsuarioModel){
            
            UsuarioDto usuarioDto = new UsuarioDto();
            usuarioDto.setId(usuario.getId());
            usuarioDto.setNome(usuario.getNome());
            usuarioDto.setEmail(usuario.getEmail());
            
            listaUsuario.add(usuarioDto);
        }
        
        return listaUsuario;
        
    }

    public void cadastrarUsuario(CadastroDto cadastro) {
        Optional<UsuarioModel> optionalUsuario = usuarioRepository.findByEmailAndStatus(cadastro.getEmail(), "ativo");

        if (optionalUsuario.isPresent()) {
            throw new  UsuarioException.EmailCadastradoException("O email já está cadastrado.");
        }

        if (cadastro.getSenha().length() <= 5) {
            throw new UsuarioException.SenhaInvalidaException("A senha deve ter mais de 5 caracteres.");
        }

        UsuarioModel usuario = new UsuarioModel();
        usuario.setNome(cadastro.getNome());
        usuario.setEmail(cadastro.getEmail());
        usuario.setSenha(cadastro.getSenha());

        usuarioRepository.save(usuario);

    }

    public void atualizarUsuario(AtualizarUsuarioDto atualizar, Long id){

        Optional<UsuarioModel> optionalUsuarioID = usuarioRepository.findByIdAndStatus(id, "ativo");
        // Verifica se o usuário com o ID inserido ja existe
        if(!optionalUsuarioID.isPresent()){
            throw new  UsuarioException.EmailCadastradoException("O ID já está cadastrado.");
        }

        // Verifica se o usuário com o email inserido ja existe
        Optional<UsuarioModel> optionalUsuarioEmail = usuarioRepository.findByEmailAndStatus(atualizar.getEmail(), "ativo");
        if (optionalUsuarioEmail.isPresent() ) {
            if (!optionalUsuarioEmail.get().getEmail().equals(optionalUsuarioID.get().getEmail())) {
                throw new  UsuarioException.EmailCadastradoException("O email já está cadastrado.");
            }
        }


        UsuarioModel usuario = optionalUsuarioID.get();
        usuario.setId(atualizar.getId());
        usuario.setNome(atualizar.getNome());
        usuario.setEmail(atualizar.getEmail());
        usuario.setSenha(atualizar.getSenha());

        usuarioRepository.save(usuario);

    }

    public boolean excluirUsuario(Long id){
        
        System.out.println("id:" + id);
        
        Optional<UsuarioModel> optionalUsuario = usuarioRepository.findById(id);
        
        if (!optionalUsuario.isPresent()){
            return false;
        }

        UsuarioModel usuario = optionalUsuario.get();
        usuario.setStatus("inativo");
        usuarioRepository.save(usuario);

        return true;
    }
    
    public UsuarioDto obterUsuario(Long id){
        
        Optional<UsuarioModel> optionalUsuario = usuarioRepository.findById(id);

        UsuarioDto usuarioDto = new UsuarioDto();
        
        if (!optionalUsuario.isPresent()){            
            usuarioDto.setId(0L);
            return usuarioDto;
        }

        usuarioDto.setId(optionalUsuario.get().getId());
        usuarioDto.setNome(optionalUsuario.get().getNome());
        usuarioDto.setEmail(optionalUsuario.get().getEmail());

        return usuarioDto;
    }


}
